######  PROGRAM MEMANGGIL WINDOWS PYQT5 ##########################
####### memanggil library PyQt5 ##################################
#----------------------------------------------------------------#
from PyQt5.QtCore import * 
from PyQt5.QtGui import * 
from PyQt5.QtQml import * 
from PyQt5.QtWidgets import *
from PyQt5.QtQuick import *
from PySide6.QtCharts import QChart
print("Qt Charts berhasil diimpor!")




import sys
import serial
import time

#----------------------------------------------------------------#


########## mengisi class table dengan instruksi pyqt5#############
#----------------------------------------------------------------#
class Backend(QObject):
    # Signal untuk mengirim status motor ke QML
    heater_status = pyqtSignal(int)  # Mengirimkan "ON" atau "OFF"
    data_suhu = pyqtSignal(float)  # Sinyal untuk suhu
    motor_status = pyqtSignal(int) 
    servo_status = pyqtSignal(int)
    
    def __init__(self):
        super().__init__()
        self.heaterStatus = 0
        self.motorStatus = 0
        self.servoStatus = 0
        try:
            self.ser = serial.Serial('com13', 9600)
            print("Reset Arduino")
            time.sleep(3)
            self.ser.write(bytes('H0\n', 'UTF-8'))  # Pastikan motor mati saat memulai
        except Exception as e:
            print(f"Error initializing serial: {e}")
            self.ser = None
            
        self.serial_thread = QThread()
        self.serial_worker = SerialReader(self.ser)
        self.serial_worker.moveToThread(self.serial_thread)
        
        self.serial_worker.data_suhu_received.connect(self.update_suhu)
        self.serial_worker.motor_status_received.connect(self.update_motor_status)
        self.serial_worker.servo_status_received.connect(self.update_servo_status)
        self.serial_worker.heater_status_received.connect(self.update_heater_status)
        
        self.serial_thread.started.connect(self.serial_worker.run)
        self.serial_thread.start()

    @pyqtSlot(int)
    def turn_onHeater(self,status):
        """Slot untuk menyalakan motor"""
        if self.ser:
            if (status == 1):
                self.ser.write(bytes('H1\n', 'UTF-8'))  # Kirim 'H' ke Arduino
                print("Heater ON")
            else:
                self.ser.write(bytes('H0\n', 'UTF-8'))  # Kirim 'L' ke Arduino
                print("Heater OFF")
            
            
    @pyqtSlot(int)
    def turn_onStirrer(self,status):
        """Slot untuk mematikan motor"""
        if self.ser:
            if (status == 1):
                self.ser.write(bytes('S1\n', 'UTF-8'))  # Kirim 'H' ke Arduino
                print("Stirrer ON")
            else:
                self.ser.write(bytes('S0\n', 'UTF-8'))  # Kirim 'L' ke Arduino
                print("Stirrer OFF")
            
    
    @pyqtSlot('int')
    def motorSpeed(self, pwm_value):
            formatted_value = f"p{pwm_value}\n"  # Tambahkan prefix
            print(f"Sent to Arduino: {formatted_value}")
            self.ser.write(bytes(formatted_value, 'UTF-8'))  # Kirim 'L' ke Arduino
    
    @pyqtSlot('int')
    def inputSuhu(self, suhu_value):
        if self.ser:
            formatted_value = f"s{suhu_value}\n"  # Tambahkan prefix
            print(f"Sent to Arduino: {suhu_value}")
            self.ser.write(bytes(formatted_value, 'UTF-8'))  # Kirim 'L' ke Arduino

    @pyqtSlot('int')
    def inputLevelAir(self, air_value):
        if self.ser:
            formatted_value = f"l{air_value}\n"  # Tambahkan prefix
            print(f"Sent to Arduino: {air_value}")
            self.ser.write(bytes(formatted_value, 'UTF-8'))  # Kirim 'L' ke Arduino
            
    @pyqtSlot(float)
    def update_suhu(self, suhu):
        """Perbarui data suhu"""
        self.currentSuhu = suhu
        self.data_suhu.emit(suhu)  # Emit ke QML atau UI
        print(f"Suhu diterima: {suhu} °C")
        
    @pyqtSlot(int)
    def update_heater_status(self, status):
        """Perbarui status motor"""
        print(f"Received heater status: {status}")  # Debugging
        if(status == 1):
            self.heaterStatus = 1
        else :
            self.heaterStatus = 0
        self.heater_status.emit(self.heaterStatus)  # Emit ke QML atau UI
        print(f"heater status: {self.heaterStatus}")
        
    @pyqtSlot(int)
    def update_motor_status(self, status):
        """Perbarui status motor"""
        print(f"Received motor status: {status}")  # Debugging
        if(status == 1):
            self.motorStatus = 1
        else :
            self.motorStatus = 0
        self.motor_status.emit(self.motorStatus)  # Emit ke QML atau UI
        print(f"Motor status: {self.motorStatus}")
        
    @pyqtSlot(int)
    def update_servo_status(self, status):
        """Perbarui status motor"""
        print(f"Received servo status: {status}")  # Debugging
        self.servoStatus = 0
        self.servo_status.emit(self.servoStatus)  # Emit ke QML atau UI
        print(f"servo status: {self.servoStatus}")
            
    @pyqtSlot()
    def quit_app(self):
        """Slot untuk menutup aplikasi"""
        if self.ser:
            self.ser.write(bytes('H0\n', 'UTF-8'))  # Pastikan motor mati sebelum keluar
            self.ser.close()
        print("Application Closed")
        QApplication.quit()



class SerialReader(QObject):
    data_suhu_received = pyqtSignal(float)  # Sinyal untuk suhu
    motor_status_received = pyqtSignal(int)
    servo_status_received = pyqtSignal(int)
    heater_status_received = pyqtSignal(int)

    def __init__(self, ser):
        super().__init__()
        self.ser = ser

    def run(self):
        """Loop untuk membaca data dari serial"""
        while self.ser and self.ser.is_open:
            try:
                if self.ser.in_waiting > 0:  # Periksa apakah ada data masuk
                    raw_data = self.ser.readline().decode('utf-8').strip()
                    print(f"Raw data received: {raw_data}")  # Debugging
                    if raw_data.startswith("c"):
                        try:
                            suhu = float(raw_data[1:])  # Ambil nilai setelah "s"
                            self.data_suhu_received.emit(suhu)  # Emit data suhu
                        except ValueError:
                            print(f"Invalid temperature data: {raw_data}")
                    elif raw_data.startswith("m"):
                        try:
                            motor_status = int(raw_data[1:])  # Ambil nilai setelah "m" (1 atau 0)
                            self.motor_status_received.emit(motor_status)  # Emit status motor
                        except ValueError:
                            print(f"Invalid motor status data: {raw_data}")
                    elif raw_data.startswith("s"):
                        try:
                            servo_status = int(raw_data[1:])  # Ambil nilai setelah "m" (1 atau 0)
                            self.servo_status_received.emit(servo_status)  # Emit status motor
                        except ValueError:
                            print(f"Invalid servo status data: {raw_data}")
                    elif raw_data.startswith("h"):
                        try:
                            heater_status = int(raw_data[1:])  # Ambil nilai setelah "m" (1 atau 0)
                            self.heater_status_received.emit(heater_status)  # Emit status motor
                        except ValueError:
                            print(f"Invalid heater status data: {raw_data}")
                    else:
                        print(f"Unrecognized data format: {raw_data}")
            except Exception as e:
                print(f"Error reading serial data: {e}")
                break
#----------------------------------------------------------------#
########## memanggil class table di mainloop######################
#-----------------------------------------`-----------------------#    
if __name__ == "__main__":
    app = QApplication(sys.argv)

    # Buat instance backend
    backend = Backend()

    app.aboutToQuit.connect(backend.quit_app)
    # Muat QML
    engine = QQmlApplicationEngine()
    engine.rootContext().setContextProperty("backend", backend)
    engine.load("main.qml")

    if not engine.rootObjects():
        sys.exit(-1)

    sys.exit(app.exec())
    
#----------------------------------------------------------------#
